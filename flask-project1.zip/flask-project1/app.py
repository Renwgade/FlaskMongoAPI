from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
from bson.objectid import ObjectId

app = Flask(__name__)

# MongoDB connection
app.config["MONGO_URI"] = "mongodb://localhost:27017/schoolDB"
mongo = PyMongo(app)

# Helper function to generate student ID
def generate_student_id():
    last_student = mongo.db.students.find().sort("student_id", -1).limit(1)
    last_student_doc = next(last_student, None)
    if last_student_doc:
        last_id = int(last_student_doc["student_id"][2:])
        return f"ST{last_id + 1:04}"
    return "ST0001"

# 1. Insert a student record
@app.route('/students', methods=['POST'])
def add_student():
    student_data = request.json
    required_fields = ["name", "age", "dob", "class", "div", "guardian_name", "address"]

    if any(field not in student_data for field in required_fields):
        return jsonify({"message": "All fields are required!"}), 400

    student_data['student_id'] = generate_student_id()
    mongo.db.students.insert_one(student_data)
    return jsonify({"message": "Student added successfully!", "student_id": student_data['student_id']}), 201

# 2. Get all student records
@app.route('/students', methods=['GET'])
def get_students():
    students = list(mongo.db.students.find())
    for student in students:
        student['_id'] = str(student['_id'])
    return jsonify(students), 200

# 3. Get specific student by ID
@app.route('/students/<student_id>', methods=['GET'])
def get_student(student_id):
    student = mongo.db.students.find_one({"student_id": student_id})
    if student:
        student['_id'] = str(student['_id'])
        return jsonify(student), 200
    return jsonify({"message": "Student not found!"}), 404

# 4. Update student details
@app.route('/students/<student_id>', methods=['PUT'])
def update_student(student_id):
    # Check if request contains JSON data
    if not request.is_json:
        return jsonify({"message": "Request body must be JSON!"}), 400

    updated_data = request.json

    # Check if updated_data is empty
    if not updated_data:
        return jsonify({"message": "Update data is required!"}), 400

    # Validate updated_data fields (optional)
    valid_fields = ["name", "age", "dob", "class", "div", "guardian_name", "address"]
    if not any(field in updated_data for field in valid_fields):
        return jsonify({"message": "At least one valid field is required for update!"}), 400

    try:
        # Update the student document
        result = mongo.db.students.update_one(
            {"student_id": student_id},
            {"$set": updated_data}
        )

        # Check if the student was found and updated
        if result.matched_count:
            if result.modified_count:
                return jsonify({"message": "Student details updated successfully!"}), 200
            else:
                return jsonify({"message": "No changes detected; student details are already up-to-date!"}), 200
        else:
            return jsonify({"message": "Student not found!"}), 404

    except Exception as e:
        # Handle MongoDB errors
        return jsonify({"message": "An error occurred while updating the student!", "error": str(e)}), 500

# 5. Search students by Name
@app.route('/students/search', methods=['GET'])
def search_students():
    name = request.args.get('name', '')
    students = list(mongo.db.students.find({"name": {"$regex": name, "$options": "i"}}))
    for student in students:
        student['_id'] = str(student['_id'])
    return jsonify(students), 200

# 6. Delete a student by ID
@app.route('/students/<student_id>', methods=['DELETE'])
def delete_student(student_id):
    result = mongo.db.students.delete_one({"student_id": student_id})
    if result.deleted_count:
        return jsonify({"message": "Student record deleted successfully!"}), 200
    return jsonify({"message": "Student not found!"}), 404

if __name__ == '__main__':
    app.run(debug=True)
